package com.backend.clase16;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase16Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase16Application.class, args);
	}

}
